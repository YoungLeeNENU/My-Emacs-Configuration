==================================
Using IPython for interactive work
==================================

.. toctree::
   :maxdepth: 2

   tutorial
   tips
   reference
   shell
   qtconsole

.. seealso::

    :doc:`/notebook/index`
